create table admin(
	admin_email varchar(50) primary key, 
	admin_passwd varchar(50) not null,
	admin_name varchar(100)
);

insert into admin values('admin@gmail.com','admin','Divya Thorat');

create table passenger(
	passenger_email varchar(50) primary key,
	passwd varchar(50) not null,
	first_name varchar(20) not null,
	last_name varchar(20) not null,
	mobile varchar(10) not null,
	gender varchar(10)
);

insert into passenger values('ram123@gmail.com','1234','Ram','Yadav','9823374979','Male'),
	('sita2022@gmail.com','1111','Sita','Yadav','9823377788','Female');


create table driver(
	driver_email varchar(50) primary key,
	passwd varchar(50) not null,
	first_name varchar(20) not null,
	last_name varchar(20) not null,
	mobile varchar(10) not null,
	gender varchar(10),
	car_model varchar(30),
	vehicle_no varchar(20),
	license_no varchar(30),
	pooling_capacity int,
	status int default 0
);

insert into driver values('abc123@gmail.com','abc123','Ramesh','Singh','9822290095','Male','Swift Desire','MH14 FG 2604','78978945',5,1);

create table rides(
	ride_id int primary key,
	ride_date date,
	driver_email varchar(50) references driver(driver_email),
	from_place varchar(30),
	to_place varchar(30),
	ride_rate float,
	departure_time time,
	available_capacity int
);

create table request_ride(
	ride_id int references rides(ride_id),
	passenger_email varchar(50) references passenger(passenger_email),	
	status varchar(50) default 'Pending',
	payment_remark varchar(50)
);



